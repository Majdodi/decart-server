// routes/auth.js

const express = require('express');
const router = express.Router();
const User = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const crypto = require('crypto');

const sendResetEmail = async (toEmail, resetLink) => {
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER, // بريد الإرسال
      pass: process.env.EMAIL_PASS  // كلمة المرور أو App Password
    }
  });

  await transporter.sendMail({
    from: `"Fragrance Store" <${process.env.EMAIL_USER}>`,
    to: toEmail,
    subject: 'Password Reset Request',
    html: `<p>Click the link below to reset your password:</p>
           <a href="${resetLink}">${resetLink}</a>`
  });
};
router.post('/forgot-password', async (req, res) => {
  const { email } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: 'Email not found' });

    // إنشاء توكن JWT صالح لمدة 15 دقيقة
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '15m' });

    // الرابط الذي سيتم إرساله للمستخدم
    const resetLink = `http://localhost:5173/reset-password/${token}`;

    // إرسال الإيميل
    await sendResetEmail(email, resetLink);

    res.json({ message: 'Email sent' });
  } catch (err) {
    console.error('Forgot password error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});


// Register
router.post('/register', async (req, res) => {
  const { name, email, password } = req.body; // ✅ أضف name هنا

  try {
    // تحقق من وجود المستخدم سابقًا
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    // تشفير كلمة المرور وتخزين المستخدم
    const hashed = await bcrypt.hash(password, 10);
    const user = new User({ name, email, password: hashed }); // ✅ استخدم name هنا أيضًا
    await user.save();

    res.status(201).json({ message: 'User created' });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Registration failed' });
  }
});


// Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(400).json({ error: 'Invalid credentials' });

    // ✅ Use env secret key
const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);

    res.json({ token, email: user.email });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Login failed' });
  }
});
// Forgot Password - Mock endpoint
router.post('/forgot-password', async (req, res) => {
  const { email } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ error: 'Email not found' });

    // توليد رمز فريد مؤقت
    const token = crypto.randomBytes(32).toString('hex');
    user.resetToken = token;
    user.tokenExpires = Date.now() + 3600000; // ساعة واحدة
    await user.save();

    // إعداد النقل
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'YOUR_EMAIL@gmail.com',
        pass: 'YOUR_APP_PASSWORD', // استخدم كلمة مرور تطبيق وليس كلمة مرور حسابك الشخصي
      },
    });

    const resetLink = `http://localhost:5173/reset-password/${token}`;

    // إرسال الإيميل
    await transporter.sendMail({
      from: 'Fragrance Store <YOUR_EMAIL@gmail.com>',
      to: user.email,
      subject: 'Reset your password',
      html: `<p>Click the link below to reset your password:</p><a href="${resetLink}">${resetLink}</a>`,
    });

    res.json({ message: 'Reset email sent successfully' });
  } catch (err) {
    console.error('Error sending reset email:', err);
    res.status(500).json({ error: 'Failed to send reset email' });
  }
});
// Change Password - Reset using token
router.post('/reset-password/:token', async (req, res) => {
  const { token } = req.params;
  const { password } = req.body;

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const hashed = await bcrypt.hash(password, 10);

    await User.findByIdAndUpdate(decoded.id, { password: hashed });

    res.json({ message: 'Password updated successfully' });
  } catch (err) {
    console.error('Reset password error:', err);
    res.status(400).json({ error: 'Invalid or expired token' });
  }
});




module.exports = router;
