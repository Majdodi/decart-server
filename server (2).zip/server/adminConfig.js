// server/adminConfig.js
module.exports = {
  adminEmail: 'modeh0220@gmail.com',
  adminPassword: '123456123', // يمكنك تغييره لاحقاً
};
